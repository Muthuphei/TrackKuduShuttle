package com.example.trackkudushuttle;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class radar extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radar);

        Button waveButton = findViewById(R.id.radder);
        waveButton.setBackgroundResource(R.drawable.waveanimation);

        AnimationDrawable waveAnimation = (AnimationDrawable) waveButton.getBackground();
        waveAnimation.start();
    }
}



